//DAO(Data Access Object)
public class PhoneDAO {
	//전화번호를 20개까지 등록할 수 있다.
	private PhoneDTO[] phoneList = new PhoneDTO[20];
	
	//전화번호 목록을 조회한다
	public PhoneDTO[] getPhoneList() {
		return phoneList;
	}
	
	public void setPhoneList(PhoneDTO[]  phoneList){
		this.phoneList = phoneList;
	}
	
	
	//선택한 전화번호 상태 정보를 조회한다.
	public PhoneDTO getPhoneOne(int no) {
		return phoneList[no-1];
	}
	
}