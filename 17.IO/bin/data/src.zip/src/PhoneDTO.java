public class PhoneDTO {
	//전화번호, 성명, 메모
	private String phone, name, memo;

	public PhoneDTO(String phone, String name, String memo) {
		//생성자에서 생성자호출하기 : 클래스명이 아니라 this로 호출한다
		//							  다른 처리는 생성자호출문 뒤에 한다
		this(phone, name);
		this.memo = memo;
	}

	public PhoneDTO(String phone, String name) {
		super();
		this.phone = phone;
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}
	
	
	
}