public class PhoneDetail {
	//선택한 Data를 조회해와 상세화면에 출력한다.
}
