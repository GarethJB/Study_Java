import java.util.Scanner;

public class PhoneMain {
	public static void main(String[] args) {
		PhoneDAO dao = new PhoneDAO();
		System.out.print("1.연락처");
		Scanner sc = new Scanner(System.in);
		if( sc.nextInt() == 1 ) {
			//연락처목록화면 연결
			new PhoneList(sc, dao);
		}
	}
}