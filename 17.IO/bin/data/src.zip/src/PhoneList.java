import java.util.Scanner;

public class PhoneList {
	//Data 목록을 조회해와 전화번호 목록을 출력한다
	private Scanner sc;
	private PhoneDAO dao;
	PhoneList(Scanner sc, PhoneDAO dao){
		this.sc = sc;
		this.dao = dao;
		display();
	}
	void display() {
		//Data 목록을 조회해온다
		PhoneDTO[] list = dao.getPhoneList();
		
		boolean exist = false;
		
		//전화번호목록을 출력한다
//		list[0] = new PhoneDTO("010-1234-5678", "홍길동");
//		list[1] = new PhoneDTO("010-1242-5463", "심청이");
		for (int i = 0; i < list.length; i++) {
			if(list[i] == null) continue;
			System.out.printf("%d. %s\n ",i+1, list[i].getName());
			if(exist == false) exist = true;
		}
		if(!exist) {
			System.out.println("등록한 연락처가 없습니다.");
			System.out.println("1. 연락처 등록하기");
			int no = sc.nextInt();
			if( no == 1) {
				new PhoneNew(sc, dao);
			}
		}
		
	}
}