import java.util.Scanner;

public class PhoneNew {
	//이름, 전화번호, 메모를 등록하는 화면
	private Scanner sc;
	private PhoneDAO dao;
	PhoneNew(Scanner sc, PhoneDAO dao){
		this.sc = sc;
		this.dao = dao;
		display();
	}
	
	void display() {
		System.out.print("이름 : ");
		String name = sc.next();
		System.out.print("전화번호 : ");
		String phone = sc.next();
		System.out.print("메모 : ");
		String memo = sc.next();
		
		PhoneDTO dto = new PhoneDTO(phone, name, memo);
		PhoneDTO[] list = dao.getPhoneList();
		//데이터를 담는 처리시에는 일반적인 배열 사용한다
		//데이터를 접근하기위해 사용시에는 향상된 for문 사용가능
		
		for (int i = 0; i < list.length; i++) {
			if(list[i]==null) {
				list[i] =dto;
				break;
			}
		}
		
		new PhoneList(sc, dao);
		
	}
}
	

